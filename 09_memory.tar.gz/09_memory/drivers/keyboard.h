#include "../cpu/types.h"

void init_keyboard();
