#include "globals.h"

u32 kmem_addr;
u32 kernel_mem_limit;

u32 umem_addr;
u32 user_mem_limit;

u32 global_id;

node *global_head;
